# Gemini Telegram Bot

Текст, фото, файлы, голосовые и генерация картинок через Gemini. Хостинг: Render, код: GitHub.

## Шаг 1. Токен Telegram
@BotFather -> /newbot -> имя и username (заканчивается на bot) -> скопируй токен.

## Шаг 2. Ключ Gemini
https://aistudio.google.com/apikey -> Create API key -> скопируй.

## Шаг 3. Свой Telegram ID (необязательно)
Напиши боту @userinfobot, он пришлёт твой id. Нужен, чтобы бот отвечал только тебе.

## Шаг 4. GitHub
1. github.com -> New repository -> имя gemini-tg-bot -> Private -> Create.
2. Add file -> Upload files -> загрузи bot.py, requirements.txt, render.yaml, .gitignore, README.md.
3. Commit changes.

## Шаг 5. Render
1. render.com -> войти через GitHub.
2. New -> Web Service -> выбери репозиторий.
3. Настройки:
   - Runtime: Python 3
   - Build Command: pip install -r requirements.txt
   - Start Command: python bot.py
   - Instance Type: Free
4. Environment Variables:
   - TELEGRAM_TOKEN = токен из шага 1
   - GEMINI_API_KEY = ключ из шага 2
   - ALLOWED_USER_IDS = твой id (необязательно)
   - PYTHON_VERSION = 3.12.3
5. Create Web Service. Подожди 2-5 минут до статуса Live.

## Шаг 6. Проверка
Напиши боту /start. В логах Render через минуту появится "keepalive: 404" — это нормально.

## Переменные
- TEXT_MODEL (по умолчанию gemini-2.5-flash)
- IMAGE_MODEL (по умолчанию gemini-2.5-flash-image)
- ADMIN_USERNAME — админ (по умолчанию Vbn13256)
- ALLOWED_USER_IDS / ALLOWED_USERNAMES — постоянный доступ (через запятую), переживает перезапуск
- SYSTEM_PROMPT — характер бота
- SAFETY_LEVEL — фильтры Gemini (BLOCK_NONE, BLOCK_ONLY_HIGH, BLOCK_MEDIUM_AND_ABOVE)
- KEEPALIVE_SECONDS — интервал самопинга (по умолчанию 600)

## Если не работает
- Бот молчит: проверь логи Render и токен.
- Ошибка ключа: проверь GEMINI_API_KEY.
- Первый ответ долгий: сервис проснулся.
- Картинки не рисуются: смени IMAGE_MODEL.

## Доступ и админ
Админ @Vbn13256: сначала напиши боту /start, чтобы он запомнил твой id.
Команды админа: /allow @username или id, /deny @username или id, /users.
Чужие получают отказ, а тебе приходит запрос с готовой командой /allow.
Список из /allow хранится в access.json и сбрасывается при новом деплое Render; для постоянного доступа внеси людей в ALLOWED_USERNAMES.
